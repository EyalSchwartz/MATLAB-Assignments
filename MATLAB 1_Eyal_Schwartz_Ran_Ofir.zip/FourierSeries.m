function [signal] = FourierSeries(Coeffs)
n = length(Coeffs);
mulMat = [0:n-1];
mulMat = mulMat'*mulMat;
mulMat = exp(2j*pi/n).^mulMat;
signal = mulMat*Coeffs';
end