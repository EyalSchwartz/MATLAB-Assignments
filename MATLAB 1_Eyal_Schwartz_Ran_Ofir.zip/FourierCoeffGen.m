function [FourierCoeff] = FourierCoeffGen(signal)
n = length(signal);
mulMat = [0:n-1];
mulMat = mulMat'*mulMat;
mulMat = exp(-2j*pi/n).^mulMat;
FourierCoeff = ((1/n).*(mulMat*signal'));
end