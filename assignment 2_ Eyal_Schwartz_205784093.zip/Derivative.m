
function [number]= Derivative(m)
    number=(log(3-3*m)-log(m))/log(2);
end
