function [y1] = func(x)
y1 = (1/16)^(x)+log2(x)/4;

