function [Number]= Equation(m)
    Number= m*log2(3)-m*log2(m)-(1-m)*log2(1-m)-1.892;
end