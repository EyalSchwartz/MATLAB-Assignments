%sketching first question graph
% finding equation roots
x= linspace(0,1);
y= x.*log2(3)-x.*log2(x)-(1.-x).*log2(1.-x)-1.892;
plot(x,y);
grid on;
hold on;
title('Equation Results','fontsize',16);
xlabel('x','FontSize',12);
ylabel('f(x)','FontSize',12);



%(Newton-Raphson Technique- Including manual derivative
n=0.1;
m=0;
z=0;
while abs(m-n)>0.00001
    m=n;
    n=m-(Equation(m))/Derivative(m);
end
n



%finding max point
x1=1;
x0=0;
s=0;
while 1
x2=(x0+x1)/2;
f1= Derivative(x1);
f2=Derivative(x2);
if f2==0
    break
elseif f2*f1<0
    x0=x2;
else
    x1=x2;
end
if abs(Equation(s)-Equation(x2))/Equation(x2)<0.0001
    break
end
s=x2;
end
Equation(x2)

%sketching second question graph
x=linspace(0,3);
    y=(1/16).^(x)+log2(x)/4;
plot(x,y);
grid on;
title('Equation Results','fontsize',16);
xlabel('x','FontSize',12);
ylabel('f(x)','FontSize',12);

%finding roots with string technique
x0=0.1;
x1=0.2;
z=0;
while 1
    x2=(x0*func(x1)-x1*func(x0))/(func(x1)-func(x0));
    if imag(x2)~=0 | x2<0
        continue
    end
    if abs(func(x2)-func(x1))<0.00001
       break;
    end
    x0=x1;
    x1=x2;
    z=z+1;
end
x2



