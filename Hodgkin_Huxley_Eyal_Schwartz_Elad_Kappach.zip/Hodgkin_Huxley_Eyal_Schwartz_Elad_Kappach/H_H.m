function [V,m,h,n,t] = H_H(I,T, v, mi, hi, ni, j)   

  dt = 0.001;               % time step for forward euler method
  loop  = ceil(T/dt);   % no. of iterations of euler
  
  gNa = 120;  
  eNa=115;
  gK = 36;  
  eK=-12;
  gL=0.3;  
  eL=10.6;

  % Initializing variable vectors
  
  t = (1:loop)*dt;
  V = zeros(loop,1);
  m = zeros(loop,1);
  h = zeros(loop,1);
  n = zeros(loop,1);
  
  % Set initial conditions
  
  V(1)=v;
  m(1)=mi;
  h(1)=hi;
  n(1)=ni;
  
  % Euler method
  
  for i=1:loop-1 
      V(i+1) = V(i) + dt*(gNa*m(i)^3*h(i)*(eNa-(V(i)+65)) + gK*n(i)^4*(eK-(V(i)+65)) + gL*(eL-(V(i)+65)) + I(i));
      m(i+1) = m(i) + dt*(alphaM(V(i))*(1-m(i)) - betaM(V(i))*m(i));
      h(i+1) = h(i) + dt*(alphaH(V(i))*(1-h(i)) - betaH(V(i))*h(i));
      n(i+1) = n(i) + dt*(alphaN(V(i))*(1-n(i)) - betaN(V(i))*n(i));
  end
  
    subplot(5,2,j);
   %figure
    plot(t,V);
    xlabel('Time (mS)');
    ylabel('MP (mV)');
    title(['Membrane Voltage Vs. Time: ' num2str(j) ' uA/cm^2']);
    
  %% סעיף 2.ב  
%     figure
%     plot(V,m);
%     xlabel('Voltage (mV)');
%     ylabel('m');
%     title('m vs. V');  
%     
%     figure
%     plot(V,n);
%     xlabel('Voltage (mV)');
%     ylabel('n');
%     title('n vs. V');
%     
%     figure
%     plot(V,h);
%     xlabel('Voltage (mV)');
%     ylabel('h');
%     title('h vs. V');
%   
end

% alpha and beta functions for the gating variables 

function aM = alphaM(V)
aM = (2.5-0.1*(V+65)) ./ (exp(2.5-0.1*(V+65)) -1);
end

function bM = betaM(V)
bM = 4*exp(-(V+65)/18);
end

function aH = alphaH(V)
aH = 0.07*exp(-(V+65)/20);
end

function bH = betaH(V)
bH = 1./(exp(3.0-0.1*(V+65))+1);
end

function aN = alphaN(V)
aN = (0.1-0.01*(V+65)) ./ (exp(1-0.1*(V+65)) -1);
end

function bN = betaN(V)
bN = 0.125*exp(-(V+65)/80);
end


