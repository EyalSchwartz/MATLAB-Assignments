
%% סעיף 3

figure
I = zeros(100000,1);
for i= 1:10
I(1:1000) = i;
subplot(5,2,i)
H_H(I, 20, -65, 0.0529, 0.5961, 0.3177, i);
end

